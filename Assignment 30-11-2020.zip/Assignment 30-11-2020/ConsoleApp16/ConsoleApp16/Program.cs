﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ConsoleApp16
{
    class Program
    {
        static void Main(string[] args)
        {


            Console.WriteLine("Enter your amount");
            int rs = Convert.ToInt32(Console.ReadLine());
            Bank b = new Bank(rs);
           
            b.NetBalance = 50000;
            
            Thread t1 = new Thread(b.deposit);
            Thread t2 = new Thread(b.withdrawal);
            Console.WriteLine("Deposit or withdraw?");
            int no = Convert.ToInt32(Console.ReadLine());
            if(no == 1)
            {
                t1.Start();

            }
            else if(no == 2)
            {
                t2.Start();
            }
            else
            {
                Console.WriteLine("Invalid Number.");
            }
            
            
        }
    }
}
