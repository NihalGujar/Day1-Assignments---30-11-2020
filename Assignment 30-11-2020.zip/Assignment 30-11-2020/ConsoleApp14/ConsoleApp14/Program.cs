﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp14
{
    class Program
    {
        static void Main(string[] args)
        { 
            Child c = new Child();
            Console.WriteLine(c.ADD(3,2));
            Parent p = new Parent();
            Console.WriteLine(p.ADD(3,2)); 
        }
    }
}
