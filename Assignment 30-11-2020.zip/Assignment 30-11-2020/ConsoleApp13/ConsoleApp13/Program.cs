﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp13
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;
            string[] str = { "Nihal", "Akash", "Yash", "Apurv", "Ameya", "Sahil","Amey" };
            Console.WriteLine(str.Contains("Akash"));

            //foreach(string s in str)
            //{
            //    if(str.Contains('%A%'))
            //    {
            //        Console.WriteLine(s);
            //    }
            //    else
            //    {
            //        Console.WriteLine("Not Starting with A");
            //    }
            //}
            for (i = 0; i < str.Length; i++)
            {
                if (str[i].Length % 2 != 0)
                {
                    Console.WriteLine(str[i]);
                }
            }

            for (i = 0;i<str.Length;i++)
            {
                for(int j = 0;j<str[i].Length;j++)
                {
                    if(str[i].Contains("a") || str[i].Contains("A"))
                    {
                        Console.WriteLine(str[i]);
                        break;
                    }
                }
            }

            

        }
    }
}
