﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15
{
    class Program 
    {
        static void Main(string[] args)
        {
            child c = new child();
            Console.WriteLine(c.sub(7, 5)); 
        }
    }
    abstract class parent
    {
        protected abstract int sub(int p, int q);
    }

    class child : parent
    {
        protected override int sub(int p, int q)
        {
            return p - q ;
        }
    }

}
