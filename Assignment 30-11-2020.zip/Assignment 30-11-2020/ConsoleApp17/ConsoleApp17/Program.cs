﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp17
{
    class Program
    {
        static void Main(string[] args)
        {
            GenericStack stk = new GenericStack();
            Stack<String> str = new Stack<string>();
            str.Push("Nihal");
            str.Push("Yash");
            str.Push("Komal");
            str.Push("Ameya");
            str.Push("Harsha");
            int ch;
            
            Console.WriteLine("1. Push");
            Console.WriteLine("2. Pop");
            Console.WriteLine("3. Sort");
            Console.WriteLine("4. Reverse");
            Console.WriteLine("5. Search");
            Console.WriteLine("6. Display");
            do
            {
                Console.WriteLine("Enter your choice");
                ch = Convert.ToInt32(Console.ReadLine());

                switch (ch)
                {
                    case 1:
                        Console.WriteLine("Enter the String:");
                        string s = Console.ReadLine();
                        stk.AddElement(str, s);
                        break;
                    case 2:
                        stk.getelement(str);
                        break;
                    case 3:
                        stk.sortStack(str);
                        break;
                    case 4:
                        stk.reverse(str);

                        break;
                    case 5:
                        Console.WriteLine("Enter the String:");
                        string s1 = Console.ReadLine();
                        stk.searchelement(str, s1);
                        break;
                    case 6:
                        stk.Displayelement(str);
                        break;
                    default:
                        Console.WriteLine("Enter valid option...");
                        break;
                }
            } while (ch != 7);
        }
    }
}
